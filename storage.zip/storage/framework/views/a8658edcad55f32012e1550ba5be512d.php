
<?php $__env->startSection('content'); ?>
    <!--begin::Content-->
    <div class="content d-flex flex-column flex-column-fluid" id="kt_content">
        <!--begin::Toolbar-->
        <div class="toolbar" id="kt_toolbar">
            <!--begin::Container-->
            <div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
                <!--begin::Page title-->
                <div data-kt-swapper="true" data-kt-swapper-mode="prepend"
                    data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                    class="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0">
                    <!--begin::Title-->

                    <!--end::Title-->
                    <!--begin::Separator-->
                    <span class="h-20px border-gray-300 border-start mx-4"></span>
                    <!--end::Separator-->
                    <!--begin::Breadcrumb-->
                    <ul class="breadcrumb breadcrumb-separatorless fw-bold fs-7 my-1">
                        <!--begin::Item-->

                        <!--end::Item-->
                        <!--begin::Item-->
                        <li class="breadcrumb-item text-muted">Rute Challenge</li>
                        <!--end::Item-->
                        <!--begin::Item-->
                        <li class="breadcrumb-item">
                            <span class="bullet bg-gray-300 w-5px h-2px"></span>
                        </li>
                        <!--end::Item-->
                        <!--begin::Item-->
                        <li class="breadcrumb-item text-dark">
                            <?php echo e(request()->routeIs('category-challenge.create') ? 'Tambah Rute Challenge' : 'Edit Rute Challenge'); ?>

                        </li>
                        <!--end::Item-->
                    </ul>
                    <!--end::Breadcrumb-->
                </div>
                <!--end::Page title-->
                <!--begin::Actions-->
            </div>
            <!--end::Container-->
        </div>
        <!--end::Toolbar-->
        <!--begin::Post-->
        <div class="post d-flex flex-column-fluid" id="kt_post">
            <!--begin::Container-->
            <div id="kt_content_container" class="container-fluid">
                <!--begin::Contacts App- Add New Contact-->
                <div class="row g-7">
                    <!--begin::Content-->
                    <div class="col-xl-12">
                        <!--begin::Contacts-->
                        <div class="card card-flush h-lg-100" id="kt_contacts_main">
                            <!--begin::Card header-->
                            <div class="card-header pt-7" id="kt_chat_contacts_header">
                                <!--begin::Card title-->
                                <div class="card-title">
                                    <!--begin::Svg Icon | path: icons/duotune/communication/com005.svg-->
                                    <span class="svg-icon svg-icon-1 me-2">
                                        
                                        
                                    </span>
                                    <!--end::Svg Icon-->
                                    <h2><?php echo e(request()->routeIs('challenge-route.create') ? 'Tambah Rute Challenge' : 'Edit Rute Challenge'); ?>

                                    </h2>
                                </div>
                                <!--end::Card title-->
                            </div>
                            <!--end::Card header-->
                            <!--begin::Card body-->
                            <div class="card-body pt-5">
                                <!--begin::Form-->
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert.alert-validation','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert.alert-validation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <form class="form"
                                    action="<?php echo e(request()->routeIs('challenge-route.create') ? route('challenge-route.store') : route('challenge-route.update', @$challenge_route->id)); ?>"
                                    method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.put-method','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.put-method'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    <!--begin::Input group-->
                                    <div class="fv-row mb-7">
                                        <!--begin::Label-->
                                        <label class="fs-6 fw-bold form-label mt-3">
                                            <span class="required">Nama Rute</span>
                                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                title="Nama Rute Challenge"></i>
                                        </label>
                                        <!--end::Label-->
                                        <!--begin::Input-->
                                        <input type="text" class="form-control form-control-solid" name="name"
                                            value="<?php echo e(@$challenge_route->name ?? old('name')); ?>" />
                                        <!--end::Input-->
                                    </div>

                                    <div class="fv-row mb-7">
                                        <!--begin::Label-->
                                        <label class="fs-6 fw-bold form-label mt-3">
                                            <span class="required">Radius Maksimal</span>
                                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                title="Masukkan maksimal radius lokasi"></i>
                                        </label>
                                        <!--end::Label-->
                                        <!--begin::Input-->
                                        <input type="number" class="form-control form-control-solid" name="radius_max"
                                            value="<?php echo e(@$challenge_route->radius_max ?? old('radius_max')); ?>" />
                                        <!--end::Input-->
                                    </div>
                                    <div class="fv-row mb-7">
                                        <!--begin::Label-->
                                        <label class="fs-6 fw-bold form-label mt-3">
                                            <span class="required">Lokasi Mulai</span>
                                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                title="Masukkan nama lokasi mulai"></i>
                                        </label>
                                        <!--end::Label-->
                                        <!--begin::Input-->
                                        <input type="text" class="form-control form-control-solid" name="start_location"
                                            value="<?php echo e(@$challenge_route->start_location ?? old('start_location')); ?>" />
                                        <!--end::Input-->
                                    </div>
                                    <div class="fv-row mb-7">
                                        <!--begin::Label-->
                                        <label class="fs-6 fw-bold form-label mt-3">
                                            <span class="required">Lokasi Finish</span>
                                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                title="Masukkan nama lokasi finish"></i>
                                        </label>
                                        <!--end::Label-->
                                        <!--begin::Input-->
                                        <input type="text" class="form-control form-control-solid" name="finish_location"
                                            value="<?php echo e(@$challenge_route->finish_location ?? old('finish_location')); ?>" />
                                        <!--end::Input-->
                                    </div>
                                    <div class="fv-row mb-7">
                                        <!--begin::Label-->
                                        <label class="fs-6 fw-bold form-label mt-3">
                                            <span class="required">Deskripsi</span>
                                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                title="Masukkan deskripsi challenge"></i>
                                        </label>
                                        <!--end::Label-->
                                        <!--begin::Input-->
                                        <textarea nama="description" id="description" class="form-control form-control-solid" rows="3"><?php echo e(@$challenge_route->description ?? old('description')); ?></textarea>
                                        <!--end::Input-->
                                    </div>

                                    <div class="fv-row mb-7">
                                        <div id="map3" style="height: 450px"></div>
                                    </div>

                                    <div class="form-group">
                                        <a type="button" class="btn btn-sm btn-outline-danger m-2"
                                            onclick="clear_polyline()">Clear Route</a>
                                    </div>
                                    <div id="map" style="height: 450px"></div>
                                    <div id="map2" style="height: 450px"></div>
                                    <input name="challenge_id" hidden="" id="challenge_id" required>
                                    <input name="lat_start" id="lat_start" required hidden="">
                                    <input name="long_start" id="long_start" required hidden="">
                                    <input name="lat_finish" id="lat_finish" required hidden="">
                                    <input name="long_finish" id="long_finish" required hidden="">
                                    <input name="route" id="route" required hidden="">


                                    <!--end::Input group-->
                                    <!--begin::Separator-->
                                    <div class="separator mb-6"></div>
                                    <!--end::Separator-->
                                    <!--begin::Action buttons-->
                                    <div class="d-flex justify-content-end">
                                        <!--begin::Button-->
                                        <button type="reset" data-kt-contacts-type="cancel"
                                            class="btn btn-light me-3">Cancel</button>
                                        <!--end::Button-->
                                        <!--begin::Button-->
                                        <button type="submit" data-kt-contacts-type="submit" class="btn btn-primary">
                                            <span class="indicator-label">Save</span>
                                            <span class="indicator-progress">Please wait...
                                                <span
                                                    class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                        </button>
                                        <!--end::Button-->
                                    </div>
                                    <!--end::Action buttons-->
                                </form>
                                <!--end::Form-->
                            </div>
                            <!--end::Card body-->
                        </div>
                        <!--end::Contacts-->
                    </div>
                    <!--end::Content-->
                </div>
                <!--end::Contacts App- Add New Contact-->
            </div>
            <!--end::Container-->
        </div>
        <!--end::Post-->
    </div>
    <!--end::Content-->
    <!--end::Wrapper-->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('assets/plugins/custom/ckeditor/ckeditor-classic.bundle.js')); ?>"></script>
    <script>
        ClassicEditor
            .create(document.querySelector('#description'))
            .catch(error => {
                console.error(error);
            });
    </script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"
        integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A=="
        crossorigin="" />
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"
        integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
        crossorigin=""></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.js"></script>
    <script src="https://unpkg.com/esri-leaflet@3.0.0/dist/esri-leaflet.js"></script>
    <script src="https://unpkg.com/esri-leaflet-vector@3.0.0/dist/esri-leaflet-vector.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/esri-leaflet-geocoder@3.0.0/dist/esri-leaflet-geocoder.css">
    <script src="https://unpkg.com/esri-leaflet-geocoder@3.0.0/dist/esri-leaflet-geocoder.js"></script>
    <script>
        //maps create
        let latitude = -6.598582861711535;
        let longitude = 106.79965282753453;

        const apiKey =
            "AAPKb22a3f2a79c44e7faf92f7c2175410835pyhwZf9KZfY4WtfUz8bLzwmHltYsHcsY2QYuJz_JPvBfKeddWZmRc1Ecfmo4DeT";

        var osmUrl = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
            osmAttrib = '&copy; <a href="https://openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            osm = L.tileLayer(osmUrl, {
                maxZoom: 18,
                attribution: osmAttrib
            }),
            map = new L.map('map', {
                center: new L.LatLng(latitude, longitude),
                zoom: 13
            }),
            drawnItems = L.featureGroup().addTo(map);

        L.control.layers({
            'osm': osm.addTo(map),
            "google": L.tileLayer('https://www.google.cn/maps/vt?lyrs=s@189&gl=cn&x={x}&y={y}&z={z}', {
                attribution: 'google'
            })
        }, {
            'drawlayer': drawnItems
        }, {
            position: 'topleft',
            collapsed: false
        }).addTo(map);
        map.addControl(new L.Control.Draw({
            edit: {
                featureGroup: drawnItems,
                poly: {
                    allowIntersection: false
                }
            },
            draw: {
                polyline: {
                    allowIntersection: false,
                    showArea: true
                },
                polygon: false,
                marker: false,
                rectangle: false,
                circle: false,
                circlemarker: false
            }
        }));


        map.on(L.Draw.Event.CREATED, function(event) {
            var layer = event.layer;
            event.layer.options.color = 'blue';
            drawnItems.addLayer(layer);
            let coordinate = layer.getLatLngs()
            $("#route").val(coordinate)
            $("#lat_start").val(coordinate[0].lat)
            $("#long_start").val(coordinate[0].lng)
            $("#lat_finish").val(Object.values(coordinate).pop().lat)
            $("#long_finish").val(Object.values(coordinate).pop().lng)

            L.marker([coordinate[0].lat, coordinate[0].lng], {
                draggable: false
            }).addTo(map);
            var Icon = new L.Icon({
                iconUrl: "<?php echo e(asset('assets/media/icons/marker-finish.png')); ?>",
                iconSize: [30, 55],
                iconAnchor: [15, 55],
                popupAnchor: [-3, -76],
            });
            L.marker([Object.values(coordinate).pop().lat, Object.values(coordinate).pop().lng], {
                draggable: false,
                icon: Icon
            }).addTo(map);
        });

        const searchControl = L.esri.Geocoding.geosearch({
            position: "topright",
            placeholder: "Cari Lokasi Awal",
            useMapBounds: false,
            providers: [L.esri.Geocoding.arcgisOnlineProvider({
                apikey: apiKey,
                nearby: {
                    lat: latitude,
                    lng: longitude
                },
            })]
        }).addTo(map);

        const results = L.layerGroup().addTo(map);

        searchControl.on("results", (data) => {
            results.clearLayers();
            for (let i = data.results.length - 1; i >= 0; i--) {
                const lngLatString =
                    `${Math.round(data.results[i].latlng.lng * 100000)/100000}, ${Math.round(data.results[i].latlng.lat * 100000)/100000}`;
                const marker = L.marker(data.results[i].latlng, {
                    draggable: true
                });
                marker.bindPopup(`<b>${lngLatString}</b><p>${data.results[i].properties.LongLabel}</p>`)
                results.addLayer(marker);
                marker.openPopup();
            }
        });


        //map edit
        var osmUrl2 = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
            osmAttrib2 = '&copy; <a href="https://openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            osm2 = L.tileLayer(osmUrl2, {
                maxZoom: 18,
                attribution: osmAttrib2
            }),
            map2 = new L.Map('map2', {
                center: new L.LatLng(latitude, longitude),
                zoom: 13
            }),
            drawnItems2 = L.featureGroup().addTo(map2);

        L.control.layers({
            'osm': osm2.addTo(map2),
            "google": L.tileLayer('https://www.google.cn/maps/vt?lyrs=s@189&gl=cn&x={x}&y={y}&z={z}', {
                attribution: 'google'
            })
        }, {
            'drawlayer': drawnItems2
        }, {
            position: 'topleft',
            collapsed: false
        }).addTo(map2);
        map2.addControl(new L.Control.Draw({
            edit: {
                featureGroup: drawnItems2,
                poly: {
                    allowIntersection: false
                }
            },
            draw: {
                polyline: {
                    allowIntersection: false,
                    showArea: true
                },
                polygon: false,
                marker: false,
                rectangle: false,
                circle: false,
                circlemarker: false
            }
        }));

        map2.on(L.Draw.Event.CREATED, function(event) {
            var layer2 = event.layer;

            drawnItems2.addLayer(layer2);

            let coordinate2 = layer2.getLatLngs()
            $("#edit_route").val(coordinate2)
            $("#edit_lat_start").val(coordinate2[0].lat)
            $("#edit_long_start").val(coordinate2[0].lng)
            $("#edit_lat_finish").val(Object.values(coordinate2).pop().lat)
            $("#edit_long_finish").val(Object.values(coordinate2).pop().lng)

            L.marker([coordinate2[0].lat, coordinate2[0].lng], {
                draggable: false
            }).addTo(map2);

            var Icon2 = new L.Icon({
                iconUrl: "<?php echo e(asset('assets/media/icons/marker-finish.png')); ?>",
                iconSize: [30, 55],
                iconAnchor: [15, 55],
                popupAnchor: [-3, -76],
            });

            L.marker([Object.values(coordinate2).pop().lat, Object.values(coordinate2).pop().lng], {
                draggable: false,
                icon: Icon2
            }).addTo(map2);
        });



        const searchControl2 = L.esri.Geocoding.geosearch({
            position: "topright",
            placeholder: "Cari Lokasi Awal",
            useMapBounds: false,
            providers: [L.esri.Geocoding.arcgisOnlineProvider({
                apikey: apiKey,
                nearby: {
                    lat: latitude,
                    lng: longitude
                },
            })]
        }).addTo(map2);



        const results2 = L.layerGroup().addTo(map2);
        searchControl2.on("results", (data) => {
            results.clearLayers();
            for (let i = data.results.length - 1; i >= 0; i--) {
                const lngLatString =
                    `${Math.round(data.results[i].latlng.lng * 100000)/100000}, ${Math.round(data.results[i].latlng.lat * 100000)/100000}`;


                const marker2 = L.marker(data.results[i].latlng, {
                    draggable: true
                });
                marker2.bindPopup(`<b>${lngLatString}</b><p>${data.results[i].properties.LongLabel}</p>`)
                results2.addLayer(marker2);
                marker2.openPopup();



            }
        });

        //maps detail
        var osmUrl3 = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
            osmAttrib3 = '&copy; <a href="https://openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            osm3 = L.tileLayer(osmUrl3, {
                maxZoom: 18,
                attribution: osmAttrib3
            }),
            map3 = new L.Map('map3', {
                center: new L.LatLng(latitude, longitude),
                zoom: 13
            }),
            drawnItems3 = L.featureGroup().addTo(map3);
        L.control.layers({
            'osm': osm3.addTo(map3),
            "google": L.tileLayer('https://www.google.cn/maps/vt?lyrs=s@189&gl=cn&x={x}&y={y}&z={z}', {
                attribution: 'google'
            })
        }, {
            'drawlayer': drawnItems3
        }, {
            position: 'topleft',
            collapsed: false
        }).addTo(map3);

        function create_route(challenge_id) {

            $("#challenge_id").val(challenge_id);
            $("#modal-create-route").modal("show")
            $("#map").animate({
                width: '100%'
            }, '400');
            setTimeout(function() {
                map.invalidateSize()
            }, 400);
        }

        function clear_polyline() {
            $(".leaflet-marker-icon").remove();
            $(".leaflet-popup").remove();
            for (i in map2._layers) {
                if (map2._layers[i]._path != undefined) {
                    try {
                        map2.removeLayer(map2._layers[i]);
                    } catch (e) {
                        console.log("problem with " + e + map2._layers[i]);
                    }
                }
            }
            for (i in map._layers) {
                if (map._layers[i]._path != undefined) {
                    try {
                        map.removeLayer(map._layers[i]);
                    } catch (e) {
                        console.log("problem with " + e + map._layers[i]);
                    }
                }
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', ['title' => 'Data Rute Challenge'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\jaktivity\resources\views/admins/challenge/challenge_route/create-edit.blade.php ENDPATH**/ ?>
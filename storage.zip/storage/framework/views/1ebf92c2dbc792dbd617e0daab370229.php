<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/global/plugins.bundle.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Load Leaflet from CDN -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"
        integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A=="
        crossorigin="" />

    <!-- Load Esri Leaflet Geocoder from CDN -->
    <link rel="stylesheet" href="https://unpkg.com/esri-leaflet-geocoder@3.0.0/dist/esri-leaflet-geocoder.css">
    <style type="text/css">
        .pointer {
            position: absolute;
            top: 90px;
            right: 60px;
            z-index: 99999;
            display: none;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!--begin::Content-->
    <div class="content d-flex flex-column flex-column-fluid" id="kt_content">
        <!--begin::Toolbar-->
        <div class="toolbar" id="kt_toolbar">
            <!--begin::Container-->
            <div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
                <!--begin::Page title-->
                <div data-kt-swapper="true" data-kt-swapper-mode="prepend"
                    data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                    class="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0">
                    <!--begin::Title-->
                    <h1 class="d-flex text-dark fw-bolder fs-3 align-items-center my-1">Data Stasiun</h1>
                    <!--end::Title-->
                    <!--begin::Separator-->
                    <span class="h-20px border-gray-300 border-start mx-4"></span>
                    <!--end::Separator-->
                    <!--begin::Breadcrumb-->
                    <ul class="breadcrumb breadcrumb-separatorless fw-bold fs-7 my-1">
                        <!--begin::Item-->
                        <li class="breadcrumb-item text-muted">Data Stasiun</li>
                        <!--end::Item-->
                        <!--begin::Item-->
                        <li class="breadcrumb-item">
                            <span class="bullet bg-gray-300 w-5px h-2px"></span>
                        </li>
                        <!--end::Item-->
                        <!--begin::Item-->
                        <li class="breadcrumb-item text-dark">
                            <?php echo e(request()->routeIs('station.create') ? 'Tambah Stasiun' : 'Edit Stasiun'); ?>

                        </li>
                        <!--end::Item-->
                    </ul>
                    <!--end::Breadcrumb-->
                </div>
            </div>
            <!--end::Container-->
        </div>
        <!--end::Toolbar-->
        <!--begin::Post-->
        <div class="post d-flex flex-column-fluid" id="kt_post">
            <!--begin::Container-->
            <div id="kt_content_container" class="container-fluid">
                <!--begin::Contacts App- Add New Contact-->
                <div class="row g-7">
                    <!--begin::Content-->
                    <div class="col-xl-12">
                        <!--begin::Contacts-->
                        <div class="card card-flush h-lg-100" id="kt_contacts_main">
                            <!--begin::Card header-->
                            <div class="card-header pt-7" id="kt_chat_contacts_header">
                                <!--begin::Card title-->
                                <div class="card-title">
                                    <!--begin::Svg Icon | path: icons/duotune/communication/com005.svg-->
                                    <span class="svg-icon svg-icon-1 me-2">
                                        
                                        <img src="<?php echo e(asset('assets/media/icons/online.svg')); ?>" alt=""
                                            class="online">
                                    </span>
                                    <!--end::Svg Icon-->
                                    <h1 class="d-flex text-dark fw-bolder fs-3 align-items-center">
                                        <?php echo e(request()->routeIs('station.create') ? 'Tambah Stasiun' : 'Edit Stasiun'); ?></h1>
                                </div>
                                <!--end::Card title-->
                            </div>
                            <!--end::Card header-->
                            <!--begin::Card body-->
                            <div class="card-body pt-5">
                                <!--begin::Form-->
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert.alert-validation','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert.alert-validation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <form class="form" id="kt_form"
                                    action="<?php echo e(request()->routeIs('station.create') ? route('station.store') : route('station.update', $station->id)); ?>"
                                    method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.put-method','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.put-method'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    <!--begin::Input group-->
                                    <div class="fv-row mb-7">
                                        <label class="fs-6 fw-bold form-label mt-3">
                                            <span class="required">Nama Stasiun</span>
                                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                title="Masukkan Nama Stasiun"></i>
                                        </label>
                                        <!--begin::Input-->
                                        <input type="text" class="form-control form-control-solid" name="name"
                                            value="<?php echo e(@$station->name ?? old('name')); ?>" required />
                                        <!--end::Input-->
                                    </div>

                                    <div class="fv-row mb-7">
                                        <label class="fs-6 fw-bold form-label mt-3">
                                            <span class="required">Poin</span>
                                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                title="Masukkan Perolehan Poin"></i>
                                        </label>
                                        <!--begin::Input-->
                                        <input type="text" class="form-control form-control-solid" name="point"
                                            value="<?php echo e(@$station->point ?? old('point')); ?>" required />
                                        <!--end::Input-->
                                    </div>

                                    <div class="fv-row mb-7">
                                        <label class="fs-6 fw-bold form-label mt-3">
                                            <span class="required">Deskripsi</span>
                                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                title="Nama Deskripsi Stasiun"></i>
                                        </label>
                                        <!--begin::Input-->
                                        <textarea name="description" id="description" cols="30" rows="10" class="form-control form-control-solid"><?php echo e(@$station->description ?? old('description')); ?></textarea>
                                        <!--end::Input-->
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <label class="fs-6 fw-bold form-label mt-3">
                                                <span class="required">Alamat</span>
                                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                    title="Alamat Stasiun"></i>
                                            </label>
                                            <!--begin::Input-->
                                            <textarea name="address" id="address" cols="30" rows="10" class="form-control form-control-solid" required><?php echo e(@$station->address ?? old('address')); ?></textarea>
                                            <!--end::Input-->
                                        </div>
                                        <div class="col-6">
                                            <!--begin::Input-->
                                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.image-upload','data' => ['name' => 'image','id' => 'image','value' => ''.e(@$station->image).'','label' => 'Pilih Foto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.image-upload'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'image','id' => 'image','value' => ''.e(@$station->image).'','label' => 'Pilih Foto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                            <!--end::Input-->
                                        </div>
                                    </div>

                                    <div class="fv-row mb-7">
                                        <label class="fs-6 fw-bold form-label mt-3">
                                            <span class="required">Urutan</span>
                                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                title="Urutan Rute Stasiun"></i>
                                        </label>
                                        <!--begin::Input-->
                                        <input type="number" class="form-control form-control-solid" name="order"
                                            value="<?php echo e(@$station->order ?? old('order')); ?>" required />
                                        <!--end::Input-->
                                    </div>

                                    <div class="fv-row mb-7">
                                        <label class="fs-6 fw-bold form-label mt-3">
                                            <span class="required">Lokasi Stasiun</span>
                                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                title="Latitude dan Longtitude Maps"></i>
                                        </label>
                                        <!--begin::Input-->
                                        <div id="map" style="height: 400px"></div>
                                        <!--end::Input-->
                                    </div>
                                    <label>Latitude</label>
                                    <input type="text" class="form-control mb-2" id="latitude" name="latitude"
                                        placeholder="latitude lokasi"
                                        value="<?php echo e(@$station->latitude ?? old('latitude')); ?>" required>
                                    <label>longitude</label>
                                    <input type="text" class="form-control mb-4" name="longitude" id="longitude"
                                        placeholder="longitude lokasi"
                                        value="<?php echo e(@$station->longitude ?? old('longitude')); ?>" required>
                                    <div class="separator mb-6"></div>
                                    <!--end::Separator-->
                                    <!--begin::Action buttons-->
                                    <div class="d-flex justify-content-end">
                                        <!--begin::Button-->
                                        <a href="<?php echo e(route('station.index')); ?>">
                                            <button type="button" data-kt-contacts-type="cancel"
                                                class="btn btn-sm btn-light me-3">Cancel</button>
                                        </a>
                                        <!--end::Button-->
                                        <!--begin::Button-->
                                        <button type="submit" data-kt-contacts-type="submit"
                                            class="btn btn-sm btn-primary">
                                            <span class="indicator-label">Simpan</span>
                                            <span class="indicator-progress">Please wait...
                                                <span
                                                    class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                        </button>
                                        <!--end::Button-->
                                    </div>
                                    <!--end::Action buttons-->
                                </form>
                                <!--end::Form-->
                            </div>
                            <!--end::Card body-->
                        </div>
                        <!--end::Contacts-->
                    </div>
                    <!--end::Content-->
                </div>
            </div>
            <!--end::Container-->
        </div>
        <!--end::Post-->
    </div>
    <!--end::Content-->
    <!--end::Wrapper-->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('assets/plugins/custom/ckeditor/ckeditor-classic.bundle.js')); ?>"></script>
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"
        integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
        crossorigin=""></script>
    <!-- Load Esri Leaflet from CDN -->
    <script src="https://unpkg.com/esri-leaflet@3.0.0/dist/esri-leaflet.js"></script>
    <script src="https://unpkg.com/esri-leaflet-vector@3.0.0/dist/esri-leaflet-vector.js"></script>
    <script src="https://unpkg.com/esri-leaflet-geocoder@3.0.0/dist/esri-leaflet-geocoder.js"></script>
    <script>
        // add ckeditor on #description
        ClassicEditor
            .create(document.querySelector('#description'))
            .catch(error => {
                console.error(error);
            });
    </script>
    <script type="text/javascript">
        let latitude = <?php echo e(@$station->latitude ?? -6.9819590695809906); ?>;
        let longitude = <?php echo e(@$station->longitude ?? 110.43680350698655); ?>;
        // let latitude = -6.9819590695809906;
        // let longitude = 110.43680350698655;


        function cek_titik_lokasi() {

            var form_lng = $('#latitude').val();
            if (form_lng.length < 3) {

                Swal.fire('Gagal menyimpan', 'silakan melengkapi titik lokasi terlebih dahulu', 'info');

            }

        }

        const apiKey =
            "AAPKb22a3f2a79c44e7faf92f7c2175410835pyhwZf9KZfY4WtfUz8bLzwmHltYsHcsY2QYuJz_JPvBfKeddWZmRc1Ecfmo4DeT";

        const basemapEnum = "ArcGIS:Navigation";

        const map = L.map("map", {
            minZoom: 2

        }).setView([latitude, longitude], 14);

        L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors',
            maxZoom: 18
        }).addTo(map);



        const searchControl = L.esri.Geocoding.geosearch({
            position: "topright",
            placeholder: "Cari Lokasi anda",
            useMapBounds: false,
            providers: [L.esri.Geocoding.arcgisOnlineProvider({
                apikey: apiKey,
                nearby: {
                    lat: latitude,
                    lng: longitude
                },
            })]
        }).addTo(map);



        var marker = L.marker([latitude, longitude], {
            draggable: true
        }).addTo(map);



        const results = L.layerGroup().addTo(map);

        searchControl.on("results", (data) => {
            map.removeLayer(marker)
            results.clearLayers();
            for (let i = data.results.length - 1; i >= 0; i--) {
                const lngLatString =
                    `${Math.round(data.results[i].latlng.lng * 100000)/100000}, ${Math.round(data.results[i].latlng.lat * 100000)/100000}`;


                const marker = L.marker(data.results[i].latlng, {
                    draggable: true
                });
                marker.bindPopup(`<b>${lngLatString}</b><p>${data.results[i].properties.LongLabel}</p>`)
                results.addLayer(marker);
                marker.openPopup();

                marker.on('dragend', function(e) {
                    document.getElementById('latitude').value = e.target._latlng.lat;
                    document.getElementById('longitude').value = e.target._latlng.lng;
                });


                document.getElementById('latitude').value = data.results[i].latlng.lat;
                document.getElementById('longitude').value = data.results[i].latlng.lng;
            }
        });

        marker.on('dragend', function(e) {

            document.getElementById('latitude').value = e.target._latlng.lat;
            document.getElementById('longitude').value = e.target._latlng.lng;
        });




        $(document).ready(function() {

            $('.pointer').show();

            setTimeout(function() {
                $('.pointer').fadeOut('slow');
            }, 3400);

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', ['title' => 'Data Stasiun'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\jaktivity\resources\views/admins/station/create-edit.blade.php ENDPATH**/ ?>
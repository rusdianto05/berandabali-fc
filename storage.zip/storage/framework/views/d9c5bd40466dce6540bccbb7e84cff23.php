<?php if(request()->routeIs('*.edit')): ?>
<?php echo method_field('PUT'); ?>
<?php endif; ?><?php /**PATH D:\Laravel\jaktivity\resources\views/components/form/put-method.blade.php ENDPATH**/ ?>
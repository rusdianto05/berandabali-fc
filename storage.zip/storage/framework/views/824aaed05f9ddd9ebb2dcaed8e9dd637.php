<a class="btn btn-sm btn-primary shadow mb-2" href="<?php echo e($action); ?>">
    <i style="font-size: 13px;" class="fa fa-info-circle me-1"></i>
    <?php echo e($label ?? 'Detail'); ?>

</a>
<?php /**PATH D:\Laravel\berandabali-fc\resources\views/components/action/show.blade.php ENDPATH**/ ?>


<form action="<?php echo e(route('broadcast.send')); ?>" method="POST" class="d-inline">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value="<?php echo e($id); ?>">
    <button type="submit" class="btn btn-sm btn-primary shadow mb-2">
        <i style="font-size: 13px;" class="fas fa-paper-plane"></i>
        Send
    </button>
</form>
<?php /**PATH D:\Laravel\jaktivity\resources\views/components/action/send.blade.php ENDPATH**/ ?>
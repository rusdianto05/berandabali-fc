
<?php $__env->startPush('css'); ?>
    <style>
        body {
            background: linear-gradient(180deg, #0e0036 24.66%, #020050 61.72%, #000000 100%);
            min-height: 100vh;
            background-repeat: no-repeat;
            color: white;
        }

        .image_article {
            height: 300px;
            object-fit: cover;
            border-radius: 10px;
        }

        #detail_article {
            padding: 6.5rem 0 5rem;
        }

        .content {
            text-align: justify;
            font-weight: 600;
            line-height: 150%;
            letter-spacing: 0.02em;
        }

        .date {
            font-weight: 500;
        }

        h1 {
            font-weight: 800;
            font-size: 2rem;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Detail Article -->
    <section id="detail_article">
        <div class="container">
            <img src="<?php echo e(asset($article->image)); ?>" class="image_article" width="100%" alt="" />
            <p class="date mt-3 mb-4"><?php echo e($article->created_at->format('d M, Y')); ?></p>
            <h1 class="text-center mb-5"><?php echo e($article->title); ?></h1>
            <p class="content">
                <?php echo $article->content; ?>

            </p>
        </div>
    </section>
    <!-- End Detail Article -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.master', ['title' => $article->title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\berandabali-fc\resources\views/frontend/article/show.blade.php ENDPATH**/ ?>
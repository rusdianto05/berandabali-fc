<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts.frontend.partials.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <!-- Navbar -->
    <?php echo $__env->make('layouts.frontend.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Navbar -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- Footer -->
    <?php echo $__env->make('layouts.frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Footer -->
    <?php echo $__env->make('layouts.frontend.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH D:\Laravel\berandabali-fc\resources\views/layouts/frontend/master.blade.php ENDPATH**/ ?>
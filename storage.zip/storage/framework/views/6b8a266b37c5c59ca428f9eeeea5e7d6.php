
<a href="<?php echo e($action); ?>" class="btn btn-sm btn-primary no-wrap shadow my-1">
    
    
    <i style="font-size: 13px;" class="fas fa-qrcode me-1"></i>Kode
</a>
<?php /**PATH D:\Laravel\jaktivity\resources\views/components/action/qr-code.blade.php ENDPATH**/ ?>
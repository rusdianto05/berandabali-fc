<a href="<?php echo e($action); ?>" class="btn btn-sm btn-warning shadow mb-2">
    <i style="font-size: 13px;" class="fa fa-edit me-1"></i>
    Edit
</a>

<?php /**PATH D:\Laravel\jaktivity\resources\views/components/action/edit.blade.php ENDPATH**/ ?>
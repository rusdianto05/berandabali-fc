<!DOCTYPE html>
<html lang="en">

<head>
    <title>Privacy Policy</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

</head>

<body>

    
    
    
    <div class="text-center">
        <img src="<?php echo e(asset('assets/media/logos/logo.png')); ?>" alt="logo" style="width: 300px; height: 100px;">
    </div>

    
    <?php echo @$appInformation->privacy_policy; ?>
</body>

</html>
<?php /**PATH D:\Laravel\jaktivity\resources\views/admins/app-information/privacy-policy.blade.php ENDPATH**/ ?>
<a data-id="form<?php echo e($id); ?>" type="button"  class="btn btn-sm btn-danger no-wrap shadow mb-2 btn-delete">
    <i style="font-size: 13px;" class="fas fa-trash me-1"></i>Delete
</a>
<form  id="form<?php echo e($id); ?>" action="<?php echo e($action); ?>" method="post">
<?php echo csrf_field(); ?>
<?php echo method_field('delete'); ?>
</form>
<?php /**PATH D:\Laravel\berandabali-fc\resources\views/components/action/delete.blade.php ENDPATH**/ ?>
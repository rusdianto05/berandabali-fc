<footer>
    <div class="container">
        <div class="text-center">
            <img src="<?php echo e(asset('/assets/frontend/images/logo.svg')); ?>" width="50" alt="" />
            <div class="d-flex gap-4 my-3 flex-wrap my-4 justify-content-center">
                <a href="<?php echo e(url('/')); ?>">Beranda</a>
                <a href="<?php echo e(url('profile-klub')); ?>">Profil Klub</a>
                <a href="<?php echo e(url('team')); ?>">Tim</a>
                <a href="<?php echo e(url('match')); ?>">Pertandingan</a>
                <a href="<?php echo e(url('galery')); ?>">Galeri</a>
                <a href="<?php echo e(url('merchandise')); ?>">Merchandise</a>
            </div>
            <hr class="hr_footer" />
            <small>&copy; <?php echo e(date('Y')); ?> Beranda Bali FC. All rights reserved.</small>
        </div>
    </div>
</footer>
<?php /**PATH D:\Laravel\berandabali-fc\resources\views/layouts/frontend/partials/footer.blade.php ENDPATH**/ ?>
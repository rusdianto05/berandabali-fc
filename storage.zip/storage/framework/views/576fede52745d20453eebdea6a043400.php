<!DOCTYPE html>
<html lang="en">

<head>
    <title>Privacy Policy</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>

<body>
    <div class="text-center">
        <img src="<?php echo e(asset('assets/media/logos/logo.png')); ?>" alt="logo" style="width: 300px; height: 100px;">
    </div>
    <?php echo @$appInformation->term_and_condition; ?>
</body>

</html>
<?php /**PATH D:\Laravel\jaktivity\resources\views/admins/app-information/terms-and-conditions.blade.php ENDPATH**/ ?>
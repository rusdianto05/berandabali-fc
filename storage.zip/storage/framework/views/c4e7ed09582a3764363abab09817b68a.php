<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/global/plugins.bundle.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!--begin::Content-->
    <div class="content d-flex flex-column flex-column-fluid" id="kt_content">
        <div class="toolbar" id="kt_toolbar">
            <!--begin::Container-->
            <div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
                <!--begin::Page title-->
                <div data-kt-swapper="true" data-kt-swapper-mode="prepend"
                    data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                    class="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0">
                    <!--begin::Title-->
                    <h1 class="d-flex text-dark fw-bolder fs-3 align-items-center my-1">Data Reward</h1>
                    <!--end::Title-->
                    <!--begin::Separator-->
                    <span class="h-20px border-gray-300 border-start mx-4"></span>
                    <!--end::Separator-->
                    <!--begin::Breadcrumb-->
                    <ul class="breadcrumb breadcrumb-separatorless fw-bold fs-7 my-1">
                        <!--begin::Item-->
                        <li class="breadcrumb-item text-muted">Data Reward</li>
                        <!--end::Item-->
                        <!--begin::Item-->
                        <li class="breadcrumb-item">
                            <span class="bullet bg-gray-300 w-5px h-2px"></span>
                        </li>
                        <!--end::Item-->
                        <!--begin::Item-->
                        <li class="breadcrumb-item text-dark">
                            <?php echo e(request()->routeIs('reward.create') ? 'Tambah Reward' : 'Edit Reward'); ?>

                        </li>
                        <!--end::Item-->
                    </ul>
                    <!--end::Breadcrumb-->
                </div>
                <!--end::Page title-->
                <!--begin::Actions-->
                
                <!--end::Actions-->
            </div>
            <!--end::Container-->
        </div>
        <!--end::Toolbar-->
        <!--begin::Post-->
        <div class="post d-flex flex-column-fluid" id="kt_post">
            <!--begin::Container-->
            <div id="kt_content_container" class="container-fluid">
                <!--begin::Contacts App- Add New Contact-->
                <div class="row g-7">
                    <!--begin::Content-->
                    <div class="col-xl-12">
                        <!--begin::Contacts-->
                        <div class="card card-flush h-lg-100" id="kt_contacts_main">
                            <!--begin::Card header-->
                            <div class="card-header pt-7" id="kt_chat_contacts_header">
                                <!--begin::Card title-->
                                <div class="card-title">
                                    <!--begin::Svg Icon | path: icons/duotune/communication/com005.svg-->
                                    <span class="svg-icon svg-icon-1 me-2">
                                        
                                        <img src="<?php echo e(asset('assets/media/icons/online.svg')); ?>" alt=""
                                            class="online">

                                    </span>
                                    <!--end::Svg Icon-->
                                    <h1 class="d-flex text-dark fw-bolder fs-3 align-items-center">
                                        <?php echo e(request()->routeIs('reward.create') ? 'Tambah Reward' : 'Edit Reward'); ?></h1>
                                </div>
                                <!--end::Card title-->
                            </div>
                            <!--end::Card header-->
                            <!--begin::Card body-->
                            <div class="card-body pt-5">
                                <!--begin::Form-->
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert.alert-validation','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert.alert-validation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <form class="form" id="kt_form"
                                    action="<?php echo e(request()->routeIs('reward.create') ? route('reward.store') : route('reward.update', $reward->id)); ?>"
                                    method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.put-method','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.put-method'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    <!--begin::Input group-->
                                    <div class="fv-row mb-7">
                                        <label class="fs-6 fw-bold form-label mt-3">
                                            <span class="required">Nama Reward</span>
                                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                title="Masukkan Nama Reward"></i>
                                        </label>
                                        <!--begin::Input-->
                                        <input type="text" class="form-control form-control-solid" name="name"
                                            value="<?php echo e(@$reward->name ?? old('name')); ?>" required />
                                        <!--end::Input-->
                                    </div>

                                    <div class="fv-row mb-7">
                                        <label class="fs-6 fw-bold form-label mt-3">
                                            <span class="required">Nama Merchant</span>
                                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                title="Nama Merchant"></i>
                                        </label>
                                        <!--begin::Input-->
                                        <select name="merchant_id" class="form-select form-select-solid"
                                            data-control="select2" data-placeholder="Select option" data-allow-clear="true"
                                            required>
                                            <option value="">--Pilih Merchant--</option>
                                            <?php $__currentLoopData = $merchants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"
                                                    <?php echo e(@$reward->merchant_id == $item->id ? 'selected' : ''); ?>>
                                                    <?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <!--end::Input-->
                                    </div>

                                    <div class="fv-row mb-7">
                                        <label class="fs-6 fw-bold form-label mt-3">
                                            <span class="required">Kategori Reward</span>
                                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                title="Nama Kategori Reward"></i>
                                        </label>
                                        <!--begin::Input-->
                                        <select name="category_reward_id" class="form-select form-select-solid"
                                            data-control="select2" data-placeholder="Select option" data-allow-clear="true"
                                            data-hide-search="true" required>
                                            <option value="">--Pilih Kategori Reward--</option>
                                            <?php $__currentLoopData = $category_rewards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"
                                                    <?php echo e(@$reward->category_reward_id == $item->id ? 'selected' : ''); ?>>
                                                    <?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <!--end::Input-->
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <label class="fs-6 fw-bold form-label mt-3">
                                                <span class="required">Tipe Reward</span>
                                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                    title="Tipe Reward dalam Rp atau Persen"></i>
                                            </label>
                                            <!--begin::Input-->
                                            <select name="type" id="type" class="form-select form-select-solid"
                                                data-control="select2" data-placeholder="Select option"
                                                data-allow-clear="true" data-hide-search="true" required>
                                                <option value="">--Pilih Kategori Reward--</option>
                                                <option value="FIXED" <?php echo e(@$reward->type == 'FIXED' ? 'selected' : ''); ?>>Rp
                                                </option>
                                                <option value="PERCENTAGE"
                                                    <?php echo e(@$reward->type == 'PERCENTAGE' ? 'selected' : ''); ?>>%</option>
                                            </select>
                                            <!--end::Input-->
                                        </div>
                                        <div class="col-6">
                                            <label class="fs-6 fw-bold form-label mt-3">
                                                <span class="required">Jumlah Reward</span>
                                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                    title="Masukkan Poin"></i>
                                            </label>
                                            <!--begin::Input-->
                                            <div class="input-group mb-5" id="fixed">
                                                <span class="input-group-text">Rp</span>
                                                <input type="text" id="money" name="value" class="form-control"
                                                    value="<?php echo e(@$reward->value); ?>" aria-label="Rupiah" />
                                            </div>
                                            <div class="input-group mb-5" id="percentage">
                                                <input type="text" id="percent" name="value" class="form-control"
                                                    value="<?php echo e(@$reward->value); ?>" aria-label="Persen" />
                                                <span class="input-group-text">%</span>
                                            </div>
                                            <!--end::Input group-->
                                            <!--end::Input-->
                                        </div>
                                    </div>

                                    <div class="fv-row mb-7">
                                        <label class="fs-6 fw-bold form-label mt-3">
                                            <span class="required">Status</span>
                                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                title="Status Kategori Reward"></i>
                                        </label>
                                        <!--begin::Input-->
                                        <select name="is_active" class="form-select form-select-solid"
                                            data-control="select2" data-placeholder="Select option"
                                            data-allow-clear="true" data-hide-search="true">
                                            <option value="1" <?php echo e(@$reward->is_active == 1 ? 'selected' : ''); ?>>Aktif
                                            </option>
                                            <option value="0" <?php echo e(@$reward->is_active == 0 ? 'selected' : ''); ?>>Tidak
                                                Aktif</option>
                                        </select>
                                        <!--end::Input-->
                                    </div>

                                    <div class="fv-row mb-7">
                                        <label class="fs-6 fw-bold form-label mt-3">
                                            <span class="required">Poin</span>
                                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                title="Masukkan Poin"></i>
                                        </label>
                                        <!--begin::Input-->
                                        <input type="number" class="form-control form-control-solid" name="point"
                                            value="<?php echo e(@$reward->point ?? old('point')); ?>" required />
                                        <!--end::Input-->
                                    </div>

                                    <div class="fv-row mb-7">
                                        <label class="fs-6 fw-bold form-label mt-3">
                                            <span class="required">Cara Pemakaian</span>
                                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                title="Penggunaan Reward"></i>
                                        </label>
                                        <!--begin::Input-->
                                        <textarea name="how_to_use" id="how_to_use" class="form-control form-control-solid" rows="3"><?php echo e(@$reward->how_to_use ?? old('how_to_use')); ?></textarea>
                                        <!--end::Input-->
                                    </div>

                                    <div class="fv-row mb-7">
                                        <label class="fs-6 fw-bold form-label mt-3">
                                            <span class="required">Deskripsi</span>
                                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip"
                                                title="Deskripsi Reward"></i>
                                        </label>
                                        <!--begin::Input-->
                                        <textarea name="description" id="description" class="form-control form-control-solid" rows="3"><?php echo e(@$reward->description ?? old('description')); ?></textarea>

                                        <!--end::Input-->
                                    </div>
                                    <div class="fv-row mb-7">
                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.image-upload','data' => ['name' => 'image','label' => 'Foto','id' => 'image','value' => ''.e(@$reward->image).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.image-upload'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'image','label' => 'Foto','id' => 'image','value' => ''.e(@$reward->image).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    </div>
                                    <!--end::Input group-->
                                    <!--begin::Separator-->
                                    <div class="separator mb-6"></div>
                                    <!--end::Separator-->
                                    <!--begin::Action buttons-->
                                    <div class="d-flex justify-content-end">
                                        <!--begin::Button-->
                                        <a href="<?php echo e(route('reward.index')); ?>">
                                            <button type="button" data-kt-contacts-type="cancel"
                                                class="btn btn-sm btn-light me-3">Cancel</button>
                                        </a>
                                        <!--end::Button-->
                                        <!--begin::Button-->
                                        <button type="submit" data-kt-contacts-type="submit"
                                            class="btn btn-sm btn-primary">
                                            <span class="indicator-label">Simpan</span>
                                            <span class="indicator-progress">Please wait...
                                                <span
                                                    class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                        </button>
                                        <!--end::Button-->
                                    </div>
                                    <!--end::Action buttons-->
                                </form>
                                <!--end::Form-->
                            </div>
                            <!--end::Card body-->
                        </div>
                        <!--end::Contacts-->
                    </div>
                    <!--end::Content-->
                </div>
            </div>
            <!--end::Container-->
        </div>
        <!--end::Post-->
    </div>
    <!--end::Content-->
    <!--end::Wrapper-->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('assets/plugins/custom/ckeditor/ckeditor-classic.bundle.js')); ?>"></script>
    <script>
        // if type value == FIXED then show input RP else show input PERCENTAGE
        $('#type').on('change', function() {
            if (this.value == 'FIXED') {
                $('#fixed').show();
                $('#percentage').hide();
            } else if (this.value == 'PERCENTAGE') {
                $('#fixed').hide();
                $('#percentage').show();
            } else {
                $('#fixed').show();
                $('#percentage').hide();
            }
        }).change();
        // add ckeditor on #description
        ClassicEditor
            .create(document.querySelector('#description'))
            .catch(error => {
                console.error(error);
            });

        // add ckeditor on #how_to_use
        ClassicEditor
            .create(document.querySelector('#how_to_use'))
            .catch(error => {
                console.error(error);
            });

        Inputmask({
            // add regex to allow only number and minimal 1 maximal 100
            regex: "^[1-9][0-9]?$|^100$",
        }).mask("#percent");

        Inputmask({
            alias: 'numeric',
            groupSeparator: '.',
            radixPoint: ',',
            autoGroup: true,
            digits: 2,
            digitsOptional: false,
            placeholder: '0',
            rightAlign: false,
            unmaskAsNumber: true,
            "greedy": false
        }).mask("#money");
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', ['title' => 'Data Reward'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\jaktivity\resources\views/admins/reward/create-edit.blade.php ENDPATH**/ ?>
<!--begin::Global Javascript Bundle(used by all pages)-->
<script src="<?php echo e(url('https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/global/plugins.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>


<!--end::Global Javascript Bundle-->
<script src="<?php echo e(asset('assets/js/scripts.bundle.js')); ?>"></script>
<!--begin::Page Vendors Javascript(used by this page)-->
<script src="<?php echo e(asset('assets/plugins/custom/fullcalendar/fullcalendar.bundle.js')); ?>"></script>
<!--end::Page Vendors Javascript-->
<!--begin::Page Custom Javascript(used by this page)-->
<script src="<?php echo e(asset('assets/js/custom/widgets.js')); ?>"></script>
<!--end::Page Custom Javascript-->
<!--begin::Page Vendors Javascript(used by this page)-->
<script src="<?php echo e(asset('assets/plugins/custom/prismjs/prismjs.bundle.js')); ?>"></script>

<script src="<?php echo e(asset('assets\js\vendors\plugins\sweetalert2.init.js')); ?>" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script src="<?php echo e(url('https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js')); ?>"></script>
<?php echo $__env->yieldPushContent('js'); ?>

<script>
    $(document).on('click', '.btn-delete', function(e) {
        var form = $("#" + e.target.dataset.id);
        Swal.fire({
            title: 'Hapus Data',
            text: 'Anda yakin akan menghapus data ini ??, data yang telah dihapus tidak dapat dikembalikan',
            icon: "question",
            showCancelButton: true,
            confirmButtonColor: 'success',
            cancelButtonColor: 'primary',
            confirmButtonText: 'Hapus',
            cancelButtonText: 'Batal'
        }).then((res) => {
            if (res.isConfirmed) {
                form.submit();
            } else {
                return false;
            }
        });
        return false;
    })
</script>
<?php if(session('success')): ?>
    <script>
        Swal.fire({
            title: 'Berhasil',
            text: '<?php echo e(session('success')); ?>',
            icon: 'success',
            confirmButtonText: 'Ok'
        })
    </script>
<?php endif; ?>
<?php if(session('error')): ?>
    <script>
        Swal.fire({
            title: 'Gagal',
            text: '<?php echo e(session('error')); ?>',
            icon: 'error',
            confirmButtonText: 'Ok'
        })
    </script>
<?php endif; ?>
<?php if(session('warning')): ?>
    <script>
        Swal.fire({
            title: 'Peringatan',
            text: '<?php echo e(session('warning')); ?>',
            icon: 'warning',
            confirmButtonText: 'Ok'
        })
    </script>
<?php endif; ?>
<?php if(session('info')): ?>
    <script>
        Swal.fire({
            title: 'Informasi',
            text: '<?php echo e(session('info')); ?>',
            icon: 'info',
            confirmButtonText: 'Ok'
        })
    </script>
<?php endif; ?>
<?php /**PATH D:\Laravel\berandabali-fc\resources\views/layouts/partials/script.blade.php ENDPATH**/ ?>
<div class="fixed-top w-100">
    <nav class="navbar navbar-expand-lg position-absolute w-100">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="<?php echo e(asset('/assets/frontend/images/logo.svg')); ?>" width="50" alt="" />
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav me-auto my-4 my-lg-0">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('/.*', '') ? ' active' : ''); ?>" aria-current="page"
                            href="/">Beranda</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link <?php echo e(request()->routeIs('profile-klub.*', 'profile-klub') ? ' active' : ''); ?>"
                            href="<?php echo e(url('profile-klub')); ?>">Profil
                            Klub</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link <?php echo e(request()->routeIs('team.*', 'team') ? ' active' : ''); ?>"
                            href="<?php echo e(url('team')); ?>">Tim</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('match.*', 'match') ? ' active' : ''); ?>"
                            href="<?php echo e(url('match')); ?>">Pertandingan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('galery.*', 'galery') ? ' active' : ''); ?>"
                            href="<?php echo e(url('galery')); ?>">Galeri</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('article.*', 'article') ? ' active' : ''); ?>"
                            href="<?php echo e(url('article')); ?>">Artikel</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('merchandise.*', 'merchandise') ? ' active' : ''); ?>"
                            href="<?php echo e(url('merchandise')); ?>">Merchandise</a>
                    </li>
                </ul>
                <div class="d-flex gap-3 align-items-center justify-content-center justify-content-lg-end">
                    <a href="<?php echo e(url('register')); ?>" class="btn_blue">Register</a>
                    <a href="<?php echo e(url('login')); ?>" class="btn_blue active">Login</a>
                </div>
            </div>
        </div>
    </nav>
</div>
<?php /**PATH D:\Laravel\berandabali-fc\resources\views/layouts/frontend/partials/navbar.blade.php ENDPATH**/ ?>
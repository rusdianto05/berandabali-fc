
<?php $__env->startPush('css'); ?>
    <style>
        body {
            color: white;
            background: linear-gradient(180deg, #0e0036 24.66%, #020050 61.72%, #000000 100%);
        }

        /* New Match */
        #new_match {
            padding: 6.5rem 0 6rem;
        }

        #new_match h1,
        #new_match h1 span,
        #ticket h1 {
            font-family: var(--lilita);
            font-size: 2.5rem !important;
        }

        .name_club {
            font-weight: 800 !important;
            font-size: 1.25rem;
            line-height: 150%;
            letter-spacing: 0.1em;
        }

        .img_logo {
            width: 200px;
        }

        .score_text,
        .score_text span {
            font-weight: 800 !important;
            font-size: 5rem;
        }

        .score_text span {
            padding: 0 1rem;
            color: #9fa0ab;
        }

        .date {
            font-weight: 700;
            color: #9fa0ab;
        }

        .btn_primary {
            position: absolute;
        }

        /* End New Match */

        /* Select ticket */
        #ticket {
            padding: 2rem 0 8rem;
        }

        #ticket h1 {
            margin-bottom: 3rem;
        }

        .box_ticket {
            background: #ffffff;
            border-radius: 8px;
            padding: 1.25rem 1rem;
            width: 30%;
        }

        .img_ticket {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 12px;
        }

        .box_ticket h6 {
            color: #0a1524;
            font-size: 1.25rem;
            font-weight: 600;
        }

        .contents p {
            font-weight: 500;
            font-size: 0.875rem;
            color: #55565b;
        }

        .box_ticket h5 {
            color: #000000;
            font-size: 1.125rem;
            font-weight: 800;
        }

        .btn_select {
            width: 100%;
            color: white;
            border: none !important;
            background: #ffd232;
            box-shadow: 0px 4px 16px rgba(0, 0, 0, 0.17);
            border-radius: 12px;
            padding: 0.5rem 2rem;
            font-weight: 800;
            font-size: 1.125rem;
        }

        .fw-medium {
            font-weight: 500;
        }

        .btn_checkout {
            background: #ffd232;
            box-shadow: 0px 4px 16px rgba(0, 0, 0, 0.17);
            border-radius: 20px;
            padding: 0.75rem 3rem;
            border: none;
            color: white;
            font-weight: 800;
            font-size: 1.5rem;
        }

        .amount h4 {
            font-weight: 800;
            font-size: 1.5rem;
        }

        button.btn_amount {
            border: none;
            padding: 0.25rem 1rem;
            background-color: transparent !important;
            color: white;
        }

        input {
            width: 2rem;
            text-align: center;
            background-color: transparent !important;
            border: none;
            color: white;
        }

        .input {
            border: 2px solid #ffffff;
            border-radius: 3px;
            text-align: center;
        }

        input[type="number"] {
            -moz-appearance: textfield;
            /* Untuk Firefox */
        }

        input[type="number"]::-webkit-inner-spin-button,
        input[type="number"]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            /* Untuk Chrome, Safari, dan Opera */
            margin: 0;
            /* Menghilangkan margin tambahan */
        }

        /* End Select ticket */
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- New Match -->
    <section id="new_match" class="container">
        <h1 class="text-center mb-5">DETAIL <span class="text_primary">PERTANDINGAN</span></h1>
        <div class="row gap-4 pt-3 justify-content-center align-items-center">
            <div class="col-md-3">
                <div class="text-center">
                    <img src="<?php echo e(asset('assets\media\logos\sidebar-logo.png')); ?>" class="img_logo" alt="" />
                </div>
                <h2 class="mt-4 text-center name_club">
                    BerandaBali <br />
                    FOOTBALL CLUB
                </h2>
            </div>
            <div class="col-md-3 text-center">
                <h2 class="score_text"><?php echo e($match->team_score); ?> <span>:</span> <?php echo e($match->opponent_score); ?>

                </h2>
                <p class="date"><?php echo e(date('d F Y', strtotime($match->match_date))); ?> |
                    <?php echo e(date('H:i', strtotime($match->match_date))); ?></p>
                <div class="d-flex gap-3 justify-content-center align-items-center mb-3">
                    <img src="/assets/frontend/images/icons/pin.svg" alt="" />
                    <p class="mb-0"><?php echo e($match->match_location); ?></p>
                </div>
                <div class="d-flex gap-3 justify-content-center align-items-center">
                    <img src="/assets/frontend/images/icons/time.svg" alt="" />
                    <p class="mb-0"><?php echo e(date('H:i', strtotime($match->match_date))); ?> -
                        <?php echo e(date('H:i', strtotime($match->match_date . ' + 2 hours'))); ?> WIB
                </div>
            </div>
            <div class="col-md-3">
                <div class="text-center">
                    <img src="<?php echo e(asset($match->opponent_logo)); ?>" class="img_logo" alt="" />
                </div>
                <h2 class="mt-4 text-center name_club">
                    <?php echo e($match->opponent_name); ?> <br />
                    FOOTBALL CLUB
                </h2>
            </div>
        </div>
    </section>
    <!-- End New Match -->

    <!-- Select tikcet -->
    <section id="ticket" class="container">
        <h1>PILIH TIKET</h1>
        <div class="d-flex gap-5 flex-wrap mb-5 justify-content-between">
            <div class="box_ticket">
                <img src="/assets/frontend/images/ticket.png" class="img_ticket" alt="" />
                <h6 class="my-3">Tribun Timur</h6>
                <div class="mb-3 contents">
                    <div class="d-flex gap-3 align-items-center mb-3">
                        <img src="/assets/frontend/images/icons/calendar.svg" alt="" />
                        <p class="mb-0">14 Januari 2023</p>
                    </div>
                    <div class="d-flex gap-3 align-items-center mb-3">
                        <img src="/assets/frontend/images/icons/pin.svg" alt="" />
                        <p class="mb-0">Beranda, Bali Utara</p>
                    </div>
                    <div class="d-flex gap-3 align-items-center">
                        <img src="/assets/frontend/images/icons/time.svg" alt="" />
                        <p class="mb-0">08.00-10.00 WITA</p>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">Rp 75.000</h5>
                    <p class="text_primary mb-0 fw-medium">Sisa 9 bangku</p>
                </div>
                <button class="btn_select">Pilih</button>
            </div>
            <div class="box_ticket">
                <img src="/assets/frontend/images/ticket.png" class="img_ticket" alt="" />
                <h6 class="my-3">Tribun Timur</h6>
                <div class="mb-3 contents">
                    <div class="d-flex gap-3 align-items-center mb-3">
                        <img src="/assets/frontend/images/icons/calendar.svg" alt="" />
                        <p class="mb-0">14 Januari 2023</p>
                    </div>
                    <div class="d-flex gap-3 align-items-center mb-3">
                        <img src="/assets/frontend/images/icons/pin.svg" alt="" />
                        <p class="mb-0">Beranda, Bali Utara</p>
                    </div>
                    <div class="d-flex gap-3 align-items-center">
                        <img src="/assets/frontend/images/icons/time.svg" alt="" />
                        <p class="mb-0">08.00-10.00 WITA</p>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">Rp 75.000</h5>
                    <p class="text_primary mb-0 fw-medium">Sisa 9 bangku</p>
                </div>
                <button class="btn_select">Pilih</button>
            </div>
            <div class="box_ticket">
                <img src="/assets/frontend/images/ticket.png" class="img_ticket" alt="" />
                <h6 class="my-3">Tribun Timur</h6>
                <div class="mb-3 contents">
                    <div class="d-flex gap-3 align-items-center mb-3">
                        <img src="/assets/frontend/images/icons/calendar.svg" alt="" />
                        <p class="mb-0">14 Januari 2023</p>
                    </div>
                    <div class="d-flex gap-3 align-items-center mb-3">
                        <img src="/assets/frontend/images/icons/pin.svg" alt="" />
                        <p class="mb-0">Beranda, Bali Utara</p>
                    </div>
                    <div class="d-flex gap-3 align-items-center">
                        <img src="/assets/frontend/images/icons/time.svg" alt="" />
                        <p class="mb-0">08.00-10.00 WITA</p>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">Rp 75.000</h5>
                    <p class="text_primary mb-0 fw-medium">Sisa 9 bangku</p>
                </div>
                <button class="btn_select">Pilih</button>
            </div>
            <div class="box_ticket">
                <img src="/assets/frontend/images/ticket.png" class="img_ticket" alt="" />
                <h6 class="my-3">Tribun Timur</h6>
                <div class="mb-3 contents">
                    <div class="d-flex gap-3 align-items-center mb-3">
                        <img src="/assets/frontend/images/icons/calendar.svg" alt="" />
                        <p class="mb-0">14 Januari 2023</p>
                    </div>
                    <div class="d-flex gap-3 align-items-center mb-3">
                        <img src="/assets/frontend/images/icons/pin.svg" alt="" />
                        <p class="mb-0">Beranda, Bali Utara</p>
                    </div>
                    <div class="d-flex gap-3 align-items-center">
                        <img src="/assets/frontend/images/icons/time.svg" alt="" />
                        <p class="mb-0">08.00-10.00 WITA</p>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">Rp 75.000</h5>
                    <p class="text_primary mb-0 fw-medium">Sisa 9 bangku</p>
                </div>
                <button class="btn_select">Pilih</button>
            </div>
            <div class="box_ticket">
                <img src="/assets/frontend/images/ticket.png" class="img_ticket" alt="" />
                <h6 class="my-3">Tribun Timur</h6>
                <div class="mb-3 contents">
                    <div class="d-flex gap-3 align-items-center mb-3">
                        <img src="/assets/frontend/images/icons/calendar.svg" alt="" />
                        <p class="mb-0">14 Januari 2023</p>
                    </div>
                    <div class="d-flex gap-3 align-items-center mb-3">
                        <img src="/assets/frontend/images/icons/pin.svg" alt="" />
                        <p class="mb-0">Beranda, Bali Utara</p>
                    </div>
                    <div class="d-flex gap-3 align-items-center">
                        <img src="/assets/frontend/images/icons/time.svg" alt="" />
                        <p class="mb-0">08.00-10.00 WITA</p>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">Rp 75.000</h5>
                    <p class="text_primary mb-0 fw-medium">Sisa 9 bangku</p>
                </div>
                <button class="btn_select">Pilih</button>
            </div>
            <div class="box_ticket">
                <img src="/assets/frontend/images/ticket.png" class="img_ticket" alt="" />
                <h6 class="my-3">Tribun Timur</h6>
                <div class="mb-3 contents">
                    <div class="d-flex gap-3 align-items-center mb-3">
                        <img src="/assets/frontend/images/icons/calendar.svg" alt="" />
                        <p class="mb-0">14 Januari 2023</p>
                    </div>
                    <div class="d-flex gap-3 align-items-center mb-3">
                        <img src="/assets/frontend/images/icons/pin.svg" alt="" />
                        <p class="mb-0">Beranda, Bali Utara</p>
                    </div>
                    <div class="d-flex gap-3 align-items-center">
                        <img src="/assets/frontend/images/icons/time.svg" alt="" />
                        <p class="mb-0">08.00-10.00 WITA</p>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">Rp 75.000</h5>
                    <p class="text_primary mb-0 fw-medium">Sisa 9 bangku</p>
                </div>
                <button class="btn_select">Pilih</button>
            </div>
        </div>
        <div class="d-flex align-items-center justify-content-between">
            <div class="amount">
                <div class="d-flex gap-4 align-items-center mb-3">
                    <h4>Jumlah</h4>
                    <div class="input d-flex">
                        <button class="btn_amount">-</button>
                        <input type="number" id="quantity" name="quantity" min="1" max="100"
                            step="1" value="1" />
                        <button class="btn_amount">+</button>
                    </div>
                </div>
                <h4 class="mb-0">Total Rp. 300.000</h4>
            </div>
            <button class="btn_checkout">Checkout</button>
        </div>
    </section>
    <!-- End Select tikcet -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.master', ['title' => 'Detail Pertandingan'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\berandabali-fc\resources\views/frontend/match/show.blade.php ENDPATH**/ ?>